# Global Context

Project:
- Fullstack portfolio + blog system

Stack:
- Frontend: Next.js (App Router)
- Backend: NestJS
- Database: PostgreSQL (on VM Linux)
- Reverse proxy: Nginx

Infrastructure:
- Local: Windows (PowerShell, NO Docker)
- Ansible node: Linux
- VM: Linux (Docker, PostgreSQL, Nginx)

Development:
- Frontend: localhost:3000
- Backend: localhost:3001
- Backend connects to DB on VM

Deployment:
- Use Ansible + Docker Compose
- 2 environments:
  - production → 80/443
  - development → 8000/8443

Git Workflow:
- feature/* → dev → main
- dev → staging (VM:8000)
- main → production (VM:80/443)

Commit:
- Use Conventional Commits
- format: type(scope): message

Rules:
- Local MUST NOT use Docker
- Always include commands to run locally
- Use PowerShell for local commands
- Use Linux commands for VM