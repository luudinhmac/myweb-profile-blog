# LƯU ĐÌNH MÁC
**System Engineer**

* [cite_start]**Ngày sinh:** 02/01/1996 [cite: 3]
* [cite_start]**Điện thoại:** 0965175646 [cite: 5]
* [cite_start]**Email:** luumac2801@gmail.com [cite: 6]
* [cite_start]**Website:** [luumac.io.vn](https://luumac.io.vn) [cite: 7]
* **Địa chỉ:** TP. [cite_start]Hồ Chí Minh, Việt Nam [cite: 8]

---

## MỤC TIÊU NGHỀ NGHIỆP
[cite_start]Kỹ sư hệ thống giàu kinh nghiệm chuyên về Linux, ảo hóa, lưu trữ và hạ tầng đám mây[cite: 10]. [cite_start]Có khả năng xử lý các sự cố hệ thống trọng yếu, tự động hóa vận hành và duy trì môi trường sẵn sàng cao (High Availability)[cite: 11].

---

## KINH NGHIỆM LÀM VIỆC

### Công ty Cổ phần Công nghệ Giải pháp Thi Thiên
**Chuyên viên Dịch vụ IT** | [cite_start]*11/2023 - Hiện tại* [cite: 13]

* [cite_start]**Triển khai hệ thống:** Thiết lập SQL Server Failover Cluster Instance (FCI) trên Windows Server 2022[cite: 13].
* [cite_start]**Quản lý lưu trữ:** Quản lý HPE MSA 2060, cấu hình iSCSI Direct Attach, MPIO và Storage Tiering để tối ưu hiệu suất[cite: 13].
* **Xử lý sự cố khẩn cấp:**
    * [cite_start]Phục hồi quyền truy cập root ESXi 8 cho Bệnh viện Đa khoa Bưu điện trong 2 giờ sau 10 ngày gián đoạn[cite: 13].
    * [cite_start]Khôi phục mật khẩu ESXi 7 cho Vietsovpetro Resort Hồ Tràm với thời gian downtime dưới 1 giờ[cite: 13].
    * [cite_start]Xử lý lỗi đồng bộ HA trên cụm HPE SimpliVity cho Báo Sài Gòn Giải Phóng[cite: 13].
* [cite_start]**Hạ tầng AI/ML:** Cài đặt CUDA drivers và cấu hình TensorFlow, PyTorch với hỗ trợ GPU[cite: 13].

### Kỹ sư Hệ thống Freelance
[cite_start]*Tháng 04/2025 & Tháng 10/2025* [cite: 13, 14]

* [cite_start]Hỗ trợ triển khai OpenStack và xử lý các lỗi dịch vụ bằng Kolla-Ansible[cite: 15, 16].
* [cite_start]Xử lý sự cố cụm Kubernetes, giúp các worker node gia nhập cụm và khôi phục workload[cite: 13].

### Công ty Cổ phần Kỹ thuật Delta (DEC)
**Chuyên viên Hệ thống IT** | [cite_start]*09/2020 - 04/2022* [cite: 15]

* [cite_start]Triển khai và vận hành hệ thống OpenStack, cụm Proxmox và lưu trữ phân tán CEPH[cite: 15].
* [cite_start]Xây dựng Private Cloud với Nextcloud tích hợp SSO qua ADFS[cite: 15].
* [cite_start]Tự động hóa các tác vụ quản trị hệ thống bằng Bash và Python, giúp giảm 80% công việc thủ công[cite: 15].
* [cite_start]Thiết lập giải pháp VDI và hệ thống giám sát với Zabbix, Grafana[cite: 15].

### Công ty CP Đầu tư Công nghệ Berjaya Gia Thịnh
**Vận hành Hệ thống** | [cite_start]*01/2019 - 12/2019* [cite: 15]

* [cite_start]Vận hành hệ thống cho Vietlott, thực hiện sao lưu dữ liệu hàng ngày/tuần vào băng từ[cite: 15].
* [cite_start]Vận hành Online Sell Server (OSS) trên hệ điều hành OpenVMS[cite: 15].

---

## KỸ NĂNG CHUYÊN MÔN

* [cite_start]**Hệ điều hành:** Linux (Ubuntu, CentOS, Debian), Windows Server[cite: 20].
* [cite_start]**Ảo hóa & Container:** VMware ESXi, vCenter, vSAN, OpenStack, Proxmox, CEPH, Docker, Kubernetes[cite: 34].
* [cite_start]**Tự động hóa:** Python, Bash, Ansible, Terraform, CI/CD Pipelines[cite: 35, 38].
* [cite_start]**Giám sát:** Prometheus, Grafana, Zabbix, Nagios, ELK Stack[cite: 36].
* [cite_start]**Mạng & Bảo mật:** Firewall (Sophos, Fortinet, pfSense), VPN, Security Monitoring (Wazuh)[cite: 22, 32].

---

## HỌC VẤN & CHỨNG CHỈ

* [cite_start]**Đại học Sư phạm Kỹ thuật TP.HCM:** Kỹ sư Công nghệ Thông tin (2014 - 2019)[cite: 45].
* **Chứng chỉ nghề nghiệp:**
    * [cite_start]DevOps & DevSecOps, Practical Kubernetes (2024)[cite: 42].
    * [cite_start]DevOps on AWS, DevOps for Business (2025)[cite: 42].
    * [cite_start]CCNA - VNPRO (2017)[cite: 42].