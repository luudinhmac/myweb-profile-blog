ansible node
192.168.157.50
user: macld
vm node
192.168.157.109
user: macld
vm k8s
192.168.157.110
user: macld
Cả 3 vm đã được cấu hình để ssh từ laptop không cần mật khẩu.
từ vm ansible node có thể ssh vào vm node và vm k8s với user macld bằng ssh key ~/.ssh/id_ed25519_ansible không cân mật khẩu.

mật khẩu user macld nếu cần để become root là admin


