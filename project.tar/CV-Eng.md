# LUU DINH MAC
**System Engineer**

* **Date of Birth:** January 2, 1996
* **Phone:** (+84) 965 175 646
* **Email:** luumac2801@gmail.com
* **Website:** [luumac.io.vn](https://luumac.io.vn)
* **Address:** Ho Chi Minh City, Vietnam

---

## PROFESSIONAL OBJECTIVE
Experienced System Engineer specializing in Linux, virtualization, storage, and cloud infrastructure. Proven ability to troubleshoot critical systems, automate operations, and maintain high availability (HA) environments.

---

## WORK EXPERIENCE

### Thi Thien Solutions Technology Corporation
**IT Services Specialist** | *Nov 2023 - Present*

* **System Deployment:** Configured SQL Server Failover Cluster Instance (FCI) on Windows Server 2022.
* **Storage Management:** Managed HPE MSA 2060, configured iSCSI Direct Attach, MPIO, and Storage Tiering to optimize performance and redundancy.
* **Critical Troubleshooting:**
    * Recovered ESXi 8 root access for Post Office General Hospital within 2 hours after a 10-day outage.
    * Reset ESXi 7 password for Vietsovpetro Resort Ho Tram with downtime under 1 hour.
    * Resolved HA synchronization issues on HPE SimpliVity clusters for Saigon Giai Phong Newspaper.
* **AI/ML Infrastructure:** Installed CUDA drivers and configured TensorFlow/PyTorch environments with GPU support.

### Freelance System Engineer
*April 2025 & October 2025*

* Assisted in OpenStack deployment and resolved service failures using Kolla-Ansible.
* Troubleshot Kubernetes clusters, fixed worker node connection issues, and restored production workloads.

### Delta Engineering Corporation (DEC)
**IT Systems Specialist** | *Sep 2020 - Apr 2022*

* Deployed and operated OpenStack, Proxmox clusters, and CEPH distributed storage.
* Built Private Cloud using Nextcloud integrated with ADFS for SSO.
* Automated system administration tasks using Bash and Python, reducing manual effort by 80%.
* Implemented VDI solutions and monitoring systems using Zabbix and Grafana.

### Berjaya Gia Thinh Investment Technology J.S.C
**System Operation** | *Jan 2019 - Dec 2019*

* Monitored Vietlott’s server systems and performed daily/weekly data backups to tape libraries.
* Operated Online Sell Server (OSS) on OpenVMS operating system.

---

## TECHNICAL SKILLS

* **Operating Systems:** Linux (Ubuntu, CentOS, Debian), Windows Server.
* **Virtualization & Containers:** VMware ESXi, vCenter, vSAN, OpenStack, Proxmox, CEPH, Docker, Kubernetes.
* **Automation & DevOps:** Python, Bash, Ansible, Terraform, Git, Jenkins, CI/CD Pipelines.
* **Monitoring:** Prometheus, Grafana, Zabbix, Nagios, ELK Stack.
* **Networking & Security:** Firewalls (Sophos, Fortinet, pfSense), VPN, Security Monitoring (Wazuh), CVE Patching.

---

## EDUCATION & CERTIFICATIONS

* **HCMC University of Technology and Education:** Engineer of Information Technology (2014 - 2019).
* **Professional Certifications:**
    * DevOps & DevSecOps, Practical Kubernetes (2024).
    * DevOps on AWS, DevOps for Business (2025).
    * CCNA - VNPRO (2017).